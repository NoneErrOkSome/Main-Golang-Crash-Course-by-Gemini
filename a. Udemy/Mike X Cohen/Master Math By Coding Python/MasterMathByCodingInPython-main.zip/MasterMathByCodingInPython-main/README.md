# Master Math by Coding in Python
Python code accompanying the course "Master Math by Coding in Python"

37+ hours of instruction (>60 hours in total, including exercises) on how to use Python as a tool for learning concepts and visualizations in mathematics.

See https://www.udemy.com/course/math-with-python/?couponCode=202311 for more details, preview videos, and to enroll in the full course.
